Đặt ảnh của bạn trong thư mục này. Gợi ý tên: cover.jpg, avatar.jpg, bai1.jpg đến bai6.jpg.
