Đặt file PDF bài tập trong thư mục này: bai1.pdf đến bai6.pdf.
